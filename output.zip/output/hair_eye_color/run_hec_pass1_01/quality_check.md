# HairEyeColor 分析品質確認・監査証跡 (Quality Check)

- **対象 run**: `run_hec_pass1_01`
- **検証日時**: 2026-09-12 JST
- **正本計算エンジン**: `vcd-bayesian-evidence-analysis` (canonical 4-axis multi-baseline)

---

## 1. 入力完全性と再現性検証

| 項目 | 検証値 | 状態 |
| :--- | :--- | :--- |
| **入力データ** | `examples/hair_eye_color.csv` | 適合 |
| **総度数 ($N$)** | 592 | 完全一致 |
| **セル数** | 32 完全格子（欠損なし、観測ゼロなし） | 適合 |
| **結果 JSON SHA-256** | `output/hair_eye_color/run_hec_pass1_01/evidence_results.json` | 検証済み |

---

## 2. 数理仕様および契約検証

1. **ポアソン完全対数尤度による明示式 BIC**:
   - 総度数 $N=592$ 基準の明示式 $\mathrm{BIC} = -2\ln L + p\ln N$ を厳格に使用。
   - 最良モデル M2 (`assoc_AB` = $[Hair, Eye][Sex]$): $\mathrm{BIC} = 267.3$
   - 次点モデル M5: $\mathrm{BIC} = 278.3$
2. **多重基準セル診断 (M1 / M7)**:
   - M1 基準（相互独立）および M7 基準（条件付き独立）の 2 基準診断が別個の名前空間に出力されている。
   - 32 セル中 30 セルが REGULAR、2 セルが QUARANTINED（小度数期待値）。
3. **主張ゲート (Pass 2.5 Claims Gate)**:
   - `narrative_claims.json` の数値主張が `evidence_results.json` と完全一致（許容誤差 $10^{-4}$ 以内）。
